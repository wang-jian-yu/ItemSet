package com.example.springboot.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.springboot.entity.AdjustRoom;

public interface AdjustRoomMapper extends BaseMapper<AdjustRoom> {
}
